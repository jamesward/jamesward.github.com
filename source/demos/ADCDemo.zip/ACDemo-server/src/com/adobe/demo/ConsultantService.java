package com.adobe.demo;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.apache.log4j.Logger;

public class ConsultantService {

	private static final String PERSISTENCE_UNIT = "consultant_db";

	private static Logger logger = Logger.getLogger(ConsultantService.class);

	public ConsultantService() {
		super();
	}

	public List<Consultant> getConsultants() {
		logger.debug("** getConsultants called...");

		EntityManagerFactory entityManagerFactory = Persistence
				.createEntityManagerFactory(PERSISTENCE_UNIT);

		EntityManager em = entityManagerFactory.createEntityManager();

		Query findAllQuery = em.createNamedQuery("consultants.findAll");
		List<Consultant> consultants = findAllQuery.getResultList();

		if (consultants != null)
			logger.debug("** Found " + consultants.size() + " records:");

		return consultants;
	}

	public void addUpdateConsultant(Consultant consultant) throws Exception {
		logger.debug("** addUpdateConsultant called...");

		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory(PERSISTENCE_UNIT);

		EntityManager em = emf.createEntityManager();

		// When passing Boolean and Number values from the Flash client to a
		// Java object, Java interprets null values as the default values for
		// primitive types; for example, 0 for double, float, long, int, short,
		// byte.
		if (consultant.getConsultantId() == null
				|| consultant.getConsultantId() == 0) {
			// New consultant is created
			consultant.setConsultantId(null);
			consultant.setCreated(new Timestamp(new Date().getTime()));
		} else {
			// Existing consultant is updated - do nothing.
		}

		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			em.merge(consultant);
			tx.commit();
		} catch (Exception e) {
			logger.error("** Error: " + e.getMessage());
			tx.rollback();
			throw new Exception(e.getMessage());
		} finally {
			logger.info("** Closing Entity Manager.");
			em.close();
		}
	}

	public void deleteConsultant(Long consultantId) {
		logger.debug("** deleteConsultant called...");

		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory(PERSISTENCE_UNIT);

		EntityManager em = emf.createEntityManager();

		Query q = em.createNamedQuery("consultants.byId");
		q.setParameter("consultantId", consultantId);
		Consultant consultant = (Consultant) q.getSingleResult();

		if (consultant != null) {
			EntityTransaction tx = em.getTransaction();
			tx.begin();
			try {
				em.remove(consultant);
				tx.commit();
			} catch (Exception e) {
				logger.error("** Error: " + e.getMessage());
				tx.rollback();
			} finally {
				logger.info("** Closing Entity Manager.");
				em.close();
			}
		}
	}
}
