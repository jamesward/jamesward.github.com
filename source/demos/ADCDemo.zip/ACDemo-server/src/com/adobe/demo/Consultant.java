package com.adobe.demo;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "consultants")
@NamedQueries( {
		@NamedQuery(name = "consultants.findAll", query = "from Consultant"),
		@NamedQuery(name = "consultants.byId", query = "select c from Consultant c where c.consultantId= :consultantId") })
public class Consultant {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "consultantId", nullable = false)
	private Long consultantId;

	@Basic
	@Index(name = "ldapName_idx_1")
	@Column(name = "ldapName", nullable = true, unique = true)
	private String ldapName;

	@Basic
	@Column(name = "firstName", nullable = true, unique = false)
	private String firstName;

	@Basic
	@Column(name = "lastName", nullable = true, unique = false)
	private String lastName;

	@Basic
	@Column(name = "title", nullable = true, unique = false)
	private String title;

	@Basic
	@Column(name = "created", nullable = false, unique = false)
	private Timestamp created;

	public Consultant() {
		super();
	}

	public Long getConsultantId() {
		return consultantId;
	}

	public void setConsultantId(Long consultantId) {
		this.consultantId = consultantId;
	}

	public String getLdapName() {
		return ldapName;
	}

	public void setLdapName(String ldapName) {
		this.ldapName = ldapName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

}
